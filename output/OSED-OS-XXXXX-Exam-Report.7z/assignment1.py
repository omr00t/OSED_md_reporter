# OSED certification challenge
# Code for assignment 1
